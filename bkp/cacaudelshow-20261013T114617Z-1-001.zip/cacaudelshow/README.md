# 🍫 Cacau Del Show - Revenda Cacau Show

Sistema web completo, elegante e responsivo em tons terrosos desenvolvido para a **Cacau Del Show - Revenda** (revenda oficial de produtos da marca Cacau Show), integrado ao **Google Planilhas** com controle de senhas via API e proteção total da área de estoque.

---

## 🔒 Segurança & Níveis de Acesso

O sistema possui separação rigorosa de acessos:

### 1. 🛍️ Catálogo Público (`index.html`)
- **Público Geral:** Clientes que desejam ver os chocolates disponíveis e fazer encomendas.
- **Proteção do Estoque:** O público **NÃO tem acesso a números de estoque interno** nem a movimentações. Apenas visualizam os produtos, preços e disponibilidade comercial (*Pronta Entrega* ou *Sob Encomenda*).
- **Sem Links Internos:** Nenhum link direto para controle de estoque na vitrine pública. Apenas um botão discreto de **"🔒 Área Restrita"** direcionando para o portal de login.
- **Sacola & WhatsApp:** O cliente monta sua seleção de produtos e pode enviar o pedido direto pelo WhatsApp com a mensagem formatada e totais calculados.

### 2. 🔑 Portal de Acesso Restrito (`login.html`)
- **Ponto Único de Entrada para a Equipe:**
  - **Perfil Administrador:** Protegido por senha mestre (padrão inicial: `admin123`).
  - **Perfil Vendedor:** Cada vendedor seleciona seu nome e digita sua senha/PIN pessoal (padrão inicial: `1234`).
- **Validação:** As senhas podem ser controladas e alteradas diretamente na planilha Google ou pelo painel do Administrador.

### 3. ⚙️ Área Administrativa (`admin.html`)
- **Acesso exclusivo para Administrador** (redireciona para o login se não autenticado).
- **Controle de Estoque Base:** Gestão do estoque da loja/depósito, cadastro de novos produtos da Cacau Show, edição de preços e ajuste rápido (+/-).
- **Gestão de Vendedores & Senhas:** Exibe retiradas, vendas, faturamento e saldo em mãos de cada vendedor, com ferramenta para alterar a senha de qualquer vendedor.
- **Histórico & Planilha:** Auditoria completa e aba de segurança para alterar a senha do próprio Administrador e sincronizar com o Google Planilhas.

### 4. 💼 Portal do Vendedor (`vendedor.html` - PDV Mobile)
- **Acesso exclusivo para Vendedores autenticados**.
- Vinculado diretamente à identidade do vendedor logado.
- **Minha Sacola:** Mostra exatamente quais produtos o vendedor retirou e tem em mãos, com botão de **Venda Rápida em 1 Toque (⚡)** e devolução de sobras.
- **Pegar do Estoque:** Retirada rápida debitando da loja/depósito e somando na sacola pessoal.
- **Lançar Venda:** Registro ágil de vendas com Pix, Dinheiro ou Cartão.

---

## 🍫 Catálogo de Produtos Cacau Show

O sistema vem pré-configurado com as principais linhas da marca Cacau Show:
- **Trufas 30g:** Tradicional, LaCreme Gianduia, Morango, Maracujá, etc.
- **Linha LaCreme:** Tabletes ao Leite, Branco e recheados com alto teor de leite e ultra cremosidade.
- **Linha Bendito Cacao:** Chocolates intensos 65%, 70% e 85% cacau.
- **Caixas & Presentes:** Bombons Finos e caixas presenteáveis.
- **Linha Montebello:** Marshmallow coberto com chocolate Cacau Show sobre base de wafer.

---

## 📁 Estrutura de Arquivos

```
cacaudelshow/
├── index.html                      # Catálogo público (sem exposição de estoque interno)
├── login.html                      # Portal de autenticação com senha (Admin e Vendedores)
├── admin.html                      # Painel restrito do Administrador (Estoque, Produtos, Senhas)
├── vendedor.html                   # PDV Mobile do Vendedor (Retiradas, Minha Sacola, Vendas)
├── css/
│   └── style.css                   # Design system terroso (cacau, caramelo, baunilha) e responsivo
├── js/
│   ├── sheets-api.js               # Camada de autenticação, senhas e sincronização com Google Sheets
│   ├── app.js                      # Lógica do catálogo público e sacola WhatsApp
│   ├── admin.js                    # Lógica do painel administrativo e guarda de rota
│   └── vendedor.js                 # Lógica do PDV mobile do vendedor e guarda de rota
├── assets/
│   └── images/                     # Vetores e artes dos produtos
│       ├── logo.svg                # Logotipo "Cacau Del Show - Revenda Cacau Show"
│       ├── trufa-70.svg            # Ilustração Trufa Cacau Show
│       ├── barra-avelas.svg        # Ilustração Tablete LaCreme / Bendito Cacao
│       ├── bombom-caramelo.svg     # Ilustração Montebello
│       ├── caixa-presente.svg      # Ilustração Caixa Presenteável
│       ├── drageas-cacau.svg       # Ilustração Drágeas
│       └── trufa-maracuja.svg      # Ilustração Trufa Branca
├── google-apps-script/
│   ├── Code.gs                     # Código Google Apps Script com autenticação por senha
│   └── INSTRUCOES_PLANILHA.md      # Guia ilustrado de instalação no Google Drive
└── README.md                       # Documentação completa
```

---

## 🚀 Como Executar e Testar

### 1. Teste Imediato (Modo Local / Offline)
Dê um duplo-clique nos arquivos diretamente no navegador:
1. Abra [index.html](index.html) para visualizar a Vitrine Pública.
2. Clique em **"🔒 Área Restrita"** ou abra [login.html](login.html).
   - Para entrar como **Administrador**: use a senha `admin123`.
   - Para entrar como **Vendedor**: selecione um vendedor e use a senha `1234`.
3. Teste cadastrar produtos, alterar estoques, retirar itens para a sacola do vendedor e lançar vendas!

### 2. Conectando ao Google Planilhas
1. Siga o guia passo a passo em [google-apps-script/INSTRUCOES_PLANILHA.md](google-apps-script/INSTRUCOES_PLANILHA.md).
2. Cole o código de `Code.gs` no Apps Script e execute `setupPlanilha()`.
3. Publique como App da Web e insira a URL na aba de configurações do painel Admin.
